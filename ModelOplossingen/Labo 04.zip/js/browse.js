window.addEventListener('load', function() {

	// usability enhancement: focus the input field
	document.getElementById('what').focus();

});

// EOF