<?php

    // redirect to Browse View
    header('location: browse.php');

// EOF