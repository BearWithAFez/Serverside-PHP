<?php

/**
 * Lab 01, Exercise 1 — Solution
 * @author Bramus Van Damme <bramus.vandamme@odisee.be>
 */

	$firstName = 'Joris';
	$lastName = 'Maervoet';

	echo 'Hello world' . PHP_EOL;
	echo 'It\'s raining outside' . PHP_EOL;
	echo 'The value of $firstName is ' . $firstName .
		 '. The value of $lastName is ' . $lastName .
		 '.' . PHP_EOL;

// EOF