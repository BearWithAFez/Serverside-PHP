<?php

/**
 * Lab 01, Exercise 5 — Solution
 * @author Joris Maervoet <joris.maervoet@odisee.be>
 */


	/*
	DEMO USAGE

	>php telwoord.php "Wat was was, voor dat was was was? Dat weet ik niet... Was?"
	Array
	(
		[was] => 6
		[dat] => 2
		[wat] => 1
		[voor] => 1
		[weet] => 1
		[ik] => 1
		[niet] => 1
	)

	*/

	if ($argc != 2) {
		echo 'Wrong number of parameters. Please supply 1 parameter to this script, e.g. "This is a sentence."'  . PHP_EOL;
	} else {
		$gefilterd = str_replace([',', ';', ':', '.', '-', '!', '?', '"', "'", '(', ')'], '', $argv[1]);
		$zin = explode(' ', $gefilterd);

		$frequenties = [];

		foreach ($zin as $woord) {
			$woord = strtolower($woord);
			if (array_key_exists( $woord, $frequenties)) {
				$frequenties[$woord]++;
			} else {
				$frequenties[$woord] = 1;
			}
		}
		arsort($frequenties);
		print_r($frequenties);
	}


//EOF