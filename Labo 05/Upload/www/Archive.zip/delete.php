<?php

    /**
     * Includes
     * ----------------------------------------------------------------
     */
    // config & functions
    require_once 'includes/config.php';
    require_once 'includes/functions.php';


    /**
     * Database Connection
     * ----------------------------------------------------------------
     */

    $db = getDatabase();


    /**
     * Initial Values
     * ----------------------------------------------------------------
     */
    $formErrors = array(); // The encountered form errors

    $id = isset($_GET['id']) ? (int) $_GET['id'] : 0; // The passed in id of the

    /**
     * Handle action 'edit' (user pressed edit button)
     * ----------------------------------------------------------------
     */

    if (isset($_POST['moduleAction']) && ($_POST['moduleAction'] == 'delete')) {

        // check if item exists (use the id from the $_POST array!)
        $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;

        $stmt = $db->query('SELECT * FROM '. DB_NAME.' WHERE id = '. $id);
        $element = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if(count($element) === 0) array_push($formErrors, 'Id not found?');


        else{
            $allOk = true;
            try {
                $stmt = $db->prepare('DELETE FROM '. DB_NAME . ' WHERE id = ?');
                $stmt->execute(array($id));
            } catch (PDOException $e) {
                array_push($formErrors, $e);
                $allOk = false;
            }
            if($allOk) header('location: browse.php');
        }
    }


    /**
     * No action to handle: show edit page
     * ----------------------------------------------------------------
     */

    $stmt = $db->query('SELECT * FROM '. DB_NAME.' WHERE '.DB_NAME.'.id = '.$id);
    $element = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(count($element) === 0) header('location: browse.php');


?><!DOCTYPE html>
<!--[if lt IE 7 ]><html class="oldie ie6" lang="en"><![endif]-->
<!--[if IE 7 ]><html class="oldie ie7" lang="en"><![endif]-->
<!--[if IE 8 ]><html class="oldie ie8" lang="en"><![endif]-->
<!--[if IE 9 ]><html class="ie9" lang="en"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang="en"><!--<![endif]-->
<head>

	<title>Todolist</title>

	<meta charset="UTF-8" />
	<meta name="viewport" content="width=520" />
	<meta http-equiv="cleartype" content="on" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

	<link rel="stylesheet" media="screen" href="css/reset.css" />
	<link rel="stylesheet" media="screen" href="css/screen.css" />

	<script src="js/delete.js"></script>

</head>
<body>

	<div id="siteWrapper">

		<!-- header -->
		<header>
			<h1><a href="index.php">Todolist</a></h1>
		</header>

		<!-- content -->
		<section>

			<div class="box" id="boxCompleteTodo">

				<h2>Complete todo</h2>

<?php
	// @TODO Persist all values below
?>

				<div class="boxInner">
					<p>Are you sure you want to complete the todo <strong>...</strong>?</p>
					<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
						<fieldset class="columns">
							<label class="column column-12 cancel alignLeft"><a href="index.php" title="Cancel and go back">Cancel and go back</a></label>
							<label for="btnSubmit" class="column column-12 alignRight"><input type="submit" id="btnSubmit" name="btnSubmit" value="Complete" /></label>
							<input type="hidden" name="id" value="<?php echo $id; ?>" />
							<input type="hidden" name="moduleAction" id="moduleAction" value="delete" />
						</fieldset>
					</form>
				</div>

			</div>

<?php
    if(count($formErrors) !== 0){
        echo '<div class="box" id="boxError"><ul class="errors">';
        for ($i = 0; $i < count($formErrors); $i++) {
            echo '<li>' . $formErrors[$i] .'</li>';
        }
        echo '</ul></div>';
    }
?>
		</section>

		<!-- footer -->
		<footer>
			<p>&copy; 2014, <a href="http://www.ikdoeict.be/" title="IkDoeICT.be">IkDoeICT.be</a></p>
		</footer>

	</div>

</body>
</html>